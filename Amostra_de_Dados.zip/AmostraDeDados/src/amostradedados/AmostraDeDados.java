/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package amostradedados;

import javax.swing.JOptionPane;

/**
 *
 * @author lyli
 */
public class AmostraDeDados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n, s=0, tot=0, med=0, cen=0, numP=0, numI=0;
        do{
            n = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe um número (Valor 0 encerra entrada de dados): "));
            if (n != 0){                
                tot+=1;
            }
            s+=n;            
            if(n>100){
                    cen++;            
            }            
            if (n%2==0 && n!=0){
                numP+=1;
            } else if (n%2!=0 && n!=0){
                numI+=1;
            }
        } while (n!=0);
        med = s/tot;
        JOptionPane.showMessageDialog(null, "<html>"+"<br>Total de valores: " 
                + tot + "<br>Total de pares: " + numP + "<br>Total de ímpares: " 
                + numI + "<br>Acima de 100: " + cen + "<br>Média dos valores: "
                + med + "</html>"); 
        
    }    
}
