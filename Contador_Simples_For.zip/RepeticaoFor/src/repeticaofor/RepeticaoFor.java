/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package repeticaofor;

/**
 *
 * @author lyli
 */
public class RepeticaoFor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /* for (int cc=0; cc<4; cc++){
            System.out.println("Cambalhota");
        }
        
        /* 
        * O código acima é a mesma coisa que:
        *   
        *    int cc = 0;
        *    while (cc<4){
        *        sout("Cambalhota");
        *       cc++;
        *    }
        *
        * onde a atribuição, a condição e o incremento fazem parte do mesmo
        * comando, são colocados juntos
        */
        
        for (int cc=100; cc>=0; cc-=10){
            System.out.println(cc);
        }
    }
    
}
